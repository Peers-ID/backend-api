-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: peers_db_v2
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `koperasi_id` int(11) NOT NULL DEFAULT '0',
  `ao_id` int(11) NOT NULL DEFAULT '0',
  `no_identitas` varchar(45) NOT NULL DEFAULT '0',
  `member_handphone` varchar(15) NOT NULL DEFAULT '0',
  `email` varchar(45) DEFAULT NULL,
  `jenis_identitas` varchar(45) DEFAULT NULL,
  `nama_lengkap` varchar(255) DEFAULT NULL,
  `tanggal_lahir` varchar(45) DEFAULT NULL,
  `usia` varchar(45) NOT NULL DEFAULT '0',
  `tempat_lahir` varchar(45) DEFAULT NULL,
  `jenis_kelamin` varchar(15) DEFAULT NULL,
  `status_perkawinan` varchar(15) DEFAULT NULL,
  `pendidikan_terakhir` varchar(45) DEFAULT NULL,
  `nama_gadis_ibu` varchar(255) DEFAULT NULL,
  `alamat_ktp_jalan` varchar(300) DEFAULT NULL,
  `alamat_ktp_kelurahan` varchar(45) DEFAULT NULL,
  `alamat_ktp_kecamatan` varchar(45) DEFAULT NULL,
  `alamat_ktp_kota` varchar(45) DEFAULT NULL,
  `alamat_ktp_provinsi` varchar(45) DEFAULT NULL,
  `alamat_ktp_status_tempat_tinggal` varchar(45) DEFAULT NULL,
  `alamat_ktp_lama_tinggal` int(3) DEFAULT '0',
  `domisili_sesuai_ktp` tinyint(1) DEFAULT '0',
  `alamat_domisili_jalan` varchar(300) DEFAULT NULL,
  `alamat_domisili_kelurahan` varchar(45) DEFAULT NULL,
  `alamat_domisili_kecamatan` varchar(45) DEFAULT NULL,
  `alamat_domisili_kota` varchar(45) DEFAULT NULL,
  `alamat_domisili_provinsi` varchar(45) DEFAULT NULL,
  `alamat_domisili_status_tempat_tinggal` varchar(45) DEFAULT NULL,
  `alamat_domisili_lama_tempat_tinggal` tinyint(3) DEFAULT '0',
  `memiliki_npwp` tinyint(1) DEFAULT '0',
  `nomer_npwp` varchar(45) DEFAULT NULL,
  `pekerja_usaha` varchar(45) DEFAULT NULL,
  `bidang_pekerja` varchar(45) DEFAULT NULL,
  `nama_perusahaan` varchar(45) DEFAULT NULL,
  `lama_bekerja` tinyint(3) DEFAULT '0',
  `penghasilan_omset` int(11) DEFAULT '0',
  `alamat_kantor_jalan` varchar(255) DEFAULT NULL,
  `alamat_kantor_kelurahan` varchar(45) DEFAULT NULL,
  `alamat_kantor_kecamatan` varchar(45) DEFAULT NULL,
  `alamat_kantor_kota` varchar(45) DEFAULT NULL,
  `alamat_kantor_provinsi` varchar(45) DEFAULT NULL,
  `nama_pasangan` varchar(100) DEFAULT NULL,
  `no_identitas_pasangan` varchar(45) DEFAULT NULL,
  `pekerjaan_pasangan` varchar(45) DEFAULT NULL,
  `no_hp_pasangan` int(30) DEFAULT NULL,
  `nama_penjamin` varchar(45) DEFAULT NULL,
  `no_hp_penjamin` int(30) DEFAULT NULL,
  `hubungan_penjamin` varchar(45) DEFAULT NULL,
  `dokumen_ktp` varchar(100) DEFAULT NULL,
  `dokumen_sim` varchar(100) DEFAULT NULL,
  `dokumen_kk` varchar(100) DEFAULT NULL,
  `dokumen_keterangan_kerja` varchar(100) DEFAULT NULL,
  `dokumen_slip_gaji` varchar(100) DEFAULT NULL,
  `dokumen_akta_nikah` varchar(100) DEFAULT NULL,
  `dokumen_bpkb` varchar(100) DEFAULT NULL,
  `dokumen_lainnya` varchar(100) DEFAULT NULL,
  `survey_luas_rumah` varchar(45) DEFAULT NULL,
  `survey_jenis_atap` varchar(45) DEFAULT NULL,
  `survey_jenis_dinding` varchar(45) DEFAULT NULL,
  `survey_kondisi_rumah` varchar(45) DEFAULT NULL,
  `survey_letak_rumah` varchar(45) DEFAULT NULL,
  `survey_tanggungan_keluarga` varchar(45) DEFAULT NULL,
  `survey_data_fisik_perabot` varchar(45) DEFAULT NULL,
  `survey_akses_lembaga_keuangan` varchar(45) DEFAULT NULL,
  `survey_info_ttg_usaha` varchar(45) DEFAULT NULL,
  `survey_index_rumah` varchar(45) DEFAULT NULL,
  `survey_index_asset` varchar(45) DEFAULT NULL,
  `survey_kepemilikan_asset` varchar(45) DEFAULT NULL,
  `survey_pendapatan_luar_usaha` varchar(45) DEFAULT NULL,
  `survey_perkembangan_asset` varchar(45) DEFAULT NULL,
  `survey_perkembangan_usaha` varchar(45) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT '0',
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `member_id_UNIQUE` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (2,24,92,'3311193477856845456','081245647734','mail@mail.com','KTP','Parnomo Sudrajat','1984-03-30 17:00:00','0','Jakarta','Laki-laki','Tidak Kawin','S1','Markiyem','Jl. Almamater','Kelurahan','Kecamatan','Kota','Jawa Barat','Sendiri',5,0,'Jl. Keimanan','','','','','',0,1,'346457882341','','','',0,0,'','','','','','Sutini','123445677',NULL,123456789,'Sutini',0,'Sodara','url','','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2020-09-15 08:35:46','2020-09-15 08:35:46'),(3,24,92,'3311193477856845459','081245647734','mail@mail.com','KTP','Manusia Biasa','1984-03-30 17:00:00','0','Jakarta','Laki-laki','Tidak Kawin','S1','Markiyem','Jl. Almamater','Kelurahan','Kecamatan','Kota','Jawa Barat','Sendiri',5,0,'Jl. Keimanan','','','','','',0,1,'346457882341','','','',0,0,'','','','','','Sutini','123445677',NULL,123456789,'Sutini',0,'Sodara','url','','','','','','','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2020-09-19 07:16:16','2020-09-19 07:16:16');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-21 21:11:40
