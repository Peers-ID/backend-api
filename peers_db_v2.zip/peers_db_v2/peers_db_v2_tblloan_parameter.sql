-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: peers_db_v2
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblloan_parameter`
--

DROP TABLE IF EXISTS `tblloan_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloan_parameter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_koperasi` int(11) NOT NULL,
  `hari_per_bulan` int(11) NOT NULL DEFAULT '30',
  `id_angsuran_sebagian` int(11) NOT NULL DEFAULT '0' COMMENT '0: Tidak\n1: Mengurangi Pokok\n2: Mengurangi Bunga',
  `id_masa_tenggang` int(11) NOT NULL DEFAULT '1' COMMENT '0: Tidak\\n1-X : Jumlah masa tenggang',
  `type_denda_keterlambatan` varchar(45) NOT NULL DEFAULT 'Persen' COMMENT 'Fix | Persen',
  `id_dasar_denda` int(11) NOT NULL DEFAULT '1' COMMENT '1: Angsuran (Pokok Pinjaman + Bunga)\n2: Pokok Pinjaman',
  `type_pelunasan_dipercepat` varchar(45) NOT NULL DEFAULT 'Persen',
  `id_dasar_pelunasan` int(11) NOT NULL DEFAULT '1' COMMENT '1: Total Sisa Pinjaman\n2: Total Pokok Pinjaman',
  `id_urutan_simpanan` varchar(45) DEFAULT NULL COMMENT '1|2|3\n1. Simpanan Sukarela\n2. Simpanan Wajib\n3. Simpanan Pokok',
  `status` varchar(45) DEFAULT 'active' COMMENT 'active\ninactive',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloan_parameter`
--

LOCK TABLES `tblloan_parameter` WRITE;
/*!40000 ALTER TABLE `tblloan_parameter` DISABLE KEYS */;
INSERT INTO `tblloan_parameter` VALUES (2,24,29,1,3,'Fix',1,'',0,'3|2|1','active','2020-09-15 08:28:05','2020-09-19 05:40:22');
/*!40000 ALTER TABLE `tblloan_parameter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-21 22:06:49
