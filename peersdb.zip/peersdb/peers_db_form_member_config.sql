-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: peers_db
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `form_member_config`
--

DROP TABLE IF EXISTS `form_member_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_member_config` (
  `koperasi_id` int(11) NOT NULL,
  `member_handphone` tinyint(1) NOT NULL DEFAULT '1',
  `jenis_identitas` tinyint(1) NOT NULL DEFAULT '0',
  `no_identitas` tinyint(1) NOT NULL DEFAULT '0',
  `nama_lengkap` tinyint(1) NOT NULL DEFAULT '0',
  `tanggal_lahir` tinyint(1) NOT NULL DEFAULT '0',
  `tempat_lahir` tinyint(1) NOT NULL DEFAULT '0',
  `jenis_kelamin` tinyint(1) NOT NULL DEFAULT '0',
  `nama_gadis_ibu` tinyint(1) NOT NULL DEFAULT '0',
  `status_perkawinan` tinyint(1) NOT NULL DEFAULT '0',
  `pendidikan_terakhir` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_jalan` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_nomer` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_rt` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_rw` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_kelurahan` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_kecamatan` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_kota` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_provinsi` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_status_tempat_tinggal` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_ktp_lama_tinggal` tinyint(1) NOT NULL DEFAULT '0',
  `domisili_sesuai_ktp` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_jalan` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_nomer` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_rt` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_rw` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_kelurahan` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_kecamatan` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_kota` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_provinsi` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_status_tempat_tinggal` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_domisili_lama_tempat_tinggal` tinyint(1) NOT NULL DEFAULT '0',
  `memiliki_npwp` tinyint(1) NOT NULL DEFAULT '0',
  `nomer_npwp` tinyint(1) NOT NULL DEFAULT '0',
  `pekerja_usaha` tinyint(1) NOT NULL DEFAULT '0',
  `bidang_pekerja` tinyint(1) NOT NULL DEFAULT '0',
  `posisi_jabatan` tinyint(1) NOT NULL DEFAULT '0',
  `nama_perusahaan` tinyint(1) NOT NULL DEFAULT '0',
  `lama_bekerja` tinyint(1) NOT NULL DEFAULT '0',
  `penghasilan_omset` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_kantor_jalan` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_kantor_nomer` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_kantor_rt` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_kantor_rw` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_kantor_kelurahan` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_kantor_kecamatan` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_kantor_kota` tinyint(1) NOT NULL DEFAULT '0',
  `alamat_kantor_provinsi` tinyint(1) NOT NULL DEFAULT '0',
  `nama` tinyint(1) NOT NULL DEFAULT '0',
  `no_hp` tinyint(1) NOT NULL DEFAULT '0',
  `hubungan` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`koperasi_id`),
  UNIQUE KEY `koperasi_id_UNIQUE` (`koperasi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_member_config`
--

LOCK TABLES `form_member_config` WRITE;
/*!40000 ALTER TABLE `form_member_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_member_config` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-04 17:59:35
