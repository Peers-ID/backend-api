-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: peers_db
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `koperasi`
--

DROP TABLE IF EXISTS `koperasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `koperasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_koperasi` varchar(255) NOT NULL,
  `no_badan_hukum` varchar(45) DEFAULT NULL,
  `tgl_badan_hukum` varchar(15) DEFAULT NULL,
  `no_perubahan_anggaran_dasar` varchar(45) DEFAULT NULL,
  `tgl_perubahan_anggaran_dasar` varchar(15) DEFAULT NULL,
  `tgl_rat_terakhir` varchar(15) DEFAULT NULL,
  `alamat` varchar(255) NOT NULL,
  `kelurahan_desa` varchar(255) NOT NULL,
  `kecamatan` varchar(255) NOT NULL,
  `kabupaten` varchar(255) NOT NULL,
  `provinsi` varchar(255) NOT NULL,
  `bentuk_koperasi` varchar(255) DEFAULT NULL,
  `jenis_koperasi` varchar(255) NOT NULL,
  `kelompok_koperasi` varchar(255) DEFAULT NULL,
  `sektor_usaha` varchar(255) DEFAULT NULL,
  `nama_ketua` varchar(255) NOT NULL,
  `nama_sekretaris` varchar(255) DEFAULT NULL,
  `nama_bendahara` varchar(255) DEFAULT NULL,
  `foto_ktp_ketua` varchar(255) DEFAULT NULL,
  `jml_anggota_pria` int(3) DEFAULT NULL,
  `jml_anggota_wanita` int(3) DEFAULT NULL,
  `total_anggota` int(3) DEFAULT NULL,
  `total_manajer` int(3) DEFAULT NULL,
  `total_karyawan` int(3) NOT NULL,
  `no_induk_koperasi` varchar(255) NOT NULL,
  `status_nik` varchar(45) DEFAULT NULL,
  `status_grade` varchar(45) DEFAULT NULL,
  `hp_pengurus` varchar(45) NOT NULL,
  `email_pengurus` varchar(45) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `koperasi`
--

LOCK TABLES `koperasi` WRITE;
/*!40000 ALTER TABLE `koperasi` DISABLE KEYS */;
INSERT INTO `koperasi` VALUES (20,'alvin','1','2020-05-01','1','2020-05-01','2020-05-01','asdfadfa','PETOJO UTARA','GAMBIR','KOTA JAKARTA PUSAT','DKI JAKARTA','aas','s','a','f','alvn','asdf','fdsa','Kop-alvin-1590944033669.jpg',1,2,2,2,4,'123141','12421','1231','081200000000','alvin@peers.id','2020-05-31 16:53:53','2020-05-31 16:53:53'),(21,'KOPERASI JASA BERKAH BARAYA NUSANTARA','011054/BH/M.KUKM.2/XII/2018','2018-12-11','','','','komplek kopo permai 1 blok i nomor 10','MARGAHAYU SELATAN','MARGAHAYU','KABUPATEN BANDUNG','JAWA BARAT','Primer Provinsi','Jasa','Koperasi Lainnya','Jasa Lainnya','Wawan Setiawan','Anton Oktaviana, S.IP','Tina Ramdhani','Kop-KOPERASI-1591087488317.jpg',50,10,60,1,5,'3204260010087','Belum Bersertifikat','D','082111629706','salomo@peers.id','2020-06-02 08:44:48','2020-06-02 08:44:48'),(22,'Koperasi Test','asd','2002-02-02','asd','2002-02-02','2002-02-02','asd','PULAU BAGUK','PULAU BANYAK','KABUPATEN ACEH SINGKIL','ACEH','asd','asd','asd','asd','asdfgh','asdfgh','asdfgh','',5,5,10,1,3,'123456789','asd','asd','0818765432','koperasi.test@gmail.com','2020-06-04 08:03:16','2020-06-04 08:03:16');
/*!40000 ALTER TABLE `koperasi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-04 17:59:37
