-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: peers_db
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `koperasi_id` int(11) NOT NULL,
  `ao_id` int(11) NOT NULL,
  `member_handphone` varchar(15) NOT NULL,
  `jenis_identitas` varchar(45) DEFAULT NULL,
  `no_identitas` varchar(45) DEFAULT NULL,
  `nama_lengkap` varchar(255) DEFAULT NULL,
  `tanggal_lahir` varchar(45) DEFAULT NULL,
  `tempat_lahir` varchar(45) DEFAULT NULL,
  `jenis_kelamin` varchar(15) DEFAULT NULL,
  `nama_gadis_ibu` varchar(255) DEFAULT NULL,
  `status_perkawinan` varchar(15) DEFAULT NULL,
  `pendidikan_terakhir` varchar(45) DEFAULT NULL,
  `alamat_ktp_jalan` varchar(255) DEFAULT NULL,
  `alamat_ktp_nomer` varchar(5) DEFAULT '0',
  `alamat_ktp_rt` int(3) DEFAULT '0',
  `alamat_ktp_rw` int(3) DEFAULT '0',
  `alamat_ktp_kelurahan` varchar(45) DEFAULT NULL,
  `alamat_ktp_kecamatan` varchar(45) DEFAULT NULL,
  `alamat_ktp_kota` varchar(45) DEFAULT NULL,
  `alamat_ktp_provinsi` varchar(45) DEFAULT NULL,
  `alamat_ktp_status_tempat_tinggal` varchar(45) DEFAULT NULL,
  `alamat_ktp_lama_tinggal` int(3) DEFAULT '0',
  `domisili_sesuai_ktp` tinyint(1) DEFAULT '0',
  `alamat_domisili_jalan` varchar(255) DEFAULT NULL,
  `alamat_domisili_nomer` varchar(5) DEFAULT '0',
  `alamat_domisili_rt` int(3) DEFAULT '0',
  `alamat_domisili_rw` int(3) DEFAULT '0',
  `alamat_domisili_kelurahan` varchar(45) DEFAULT NULL,
  `alamat_domisili_kecamatan` varchar(45) DEFAULT NULL,
  `alamat_domisili_kota` varchar(45) DEFAULT NULL,
  `alamat_domisili_provinsi` varchar(45) DEFAULT NULL,
  `alamat_domisili_status_tempat_tinggal` varchar(45) DEFAULT NULL,
  `alamat_domisili_lama_tempat_tinggal` tinyint(3) DEFAULT '0',
  `memiliki_npwp` tinyint(1) DEFAULT '0',
  `nomer_npwp` varchar(45) DEFAULT NULL,
  `pekerja_usaha` varchar(45) DEFAULT NULL,
  `bidang_pekerja` varchar(45) DEFAULT NULL,
  `posisi_jabatan` varchar(45) DEFAULT NULL,
  `nama_perusahaan` varchar(45) DEFAULT NULL,
  `lama_bekerja` tinyint(1) DEFAULT '0',
  `penghasilan_omset` int(11) DEFAULT '0',
  `alamat_kantor_jalan` varchar(255) DEFAULT NULL,
  `alamat_kantor_nomer` varchar(5) DEFAULT '0',
  `alamat_kantor_rt` int(3) DEFAULT '0',
  `alamat_kantor_rw` int(3) DEFAULT '0',
  `alamat_kantor_kelurahan` varchar(45) DEFAULT NULL,
  `alamat_kantor_kecamatan` varchar(45) DEFAULT NULL,
  `alamat_kantor_kota` varchar(45) DEFAULT NULL,
  `alamat_kantor_provinsi` varchar(45) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `hubungan` varchar(45) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT '0',
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `member_id_UNIQUE` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (19,0,74,'08170500864','SIM','1231232','kekeyi','2020-06-06 00:00:00','wqeqwew','Wanita','asdas','Cerai','Lainnya','fdsdfda','1',2,3,'','WONOSARI','KABUPATEN BOALEMO','GORONTALO','Sewa/Kontrak',37,1,'fdsdfda','1',2,3,'','WONOSARI','KABUPATEN BOALEMO','GORONTALO','Sewa/Kontrak',37,0,'','Pensiunan','qeqw','adas','zxcz',12,1232121,'zxczx','2',3,4,'','PELAWAN','KABUPATEN SAROLANGUN','JAMBI','vcbcv','08217356127','Lainnya',1,'2020-06-05 23:29:56','2020-06-05 23:29:56'),(20,0,87,'08170500864','SIM','1234556','palsu','2020-06-06 00:00:00','wqeqwew','Wanita','asdas','Nikah','SMP','fsdhg','1',2,3,NULL,'WONOSARI','wrewt','twe','gdsgs',43,1,'fsdgs','4',3,1,NULL,'Bandung','dfs','gdss','sdgs',23,1,NULL,'PNS','sdf','d','sgd',23,3235,'vdg','4',2,4,NULL,'sdfs','sdg','gdg',NULL,NULL,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-04 17:59:39
