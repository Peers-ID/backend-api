-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: peers_db
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `koperasi_id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `phone_mobile` varchar(45) NOT NULL,
  `birthdate` varchar(45) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `ak_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL COMMENT 'ak_id=admin koperasi added when new ao agent created',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,0,'Jessica Jiang','087713424662','02-Des-1988','jessica@gmail.com','$2a$10$E.3mpUjF38HRAaVggz4dTObUcxB1ZNj6HfXWtqsRv3lci9YKU1EUS','Admin Peers',NULL,'active','2020-02-13 16:46:57','2020-05-07 04:57:00'),(70,20,'alvin','081200000000','2020-05-31 16:53:53','alvin@peers.id','$2a$10$q1pIjeNpbg4YEGs4Oh.3muOGY8tWHBz0YEz2gpHC7tTJzsDxoEHAu','Admin Koperasi',0,'active','2020-05-31 16:53:53','2020-05-31 16:54:32'),(71,20,'alvin','081228335633','2020-05-01 00:00:00','unlimitedalvin@gmail.com','$2a$10$GXkIN1LBwaupue4gF3KgC.9vsZPoKwkDKgMbYisO4UCxrIm/DZ7jS','Admin AO',70,'active','2020-05-31 16:54:59','2020-06-08 12:18:45'),(72,21,'KOPERASI JASA BERKAH BARAYA NUSANTARA','082111629706','2020-06-02 08:44:48','salomo@peers.id','$2a$10$Nm4SMZAglPrUAEgds9xEk.5t54S17a2rmoRyQRgmaEpDcq9B.joWa','Admin Koperasi',0,'active','2020-06-02 08:44:48','2020-06-02 08:44:48'),(73,22,'Koperasi Test','0818765432','2020-06-04 08:03:16','koperasi.test@gmail.com','$2a$10$rxKIgzwzl15/Q5.x6.wAKeDmL2/v6miyIc.D2QfJcrY5xS6s2gtIS','Admin Koperasi',0,'active','2020-06-04 08:03:16','2020-06-04 08:08:41'),(74,22,'Emma Watson','0812345678','2010-10-10 00:00:00','emma.watson@gmail.com','$2a$10$6wNwQ4kkgvraAOiuKal49OERvG72oj5bIO832WOLdj4IVZLgXKG/i','Admin AO',73,'active','2020-06-04 08:05:59','2020-06-04 08:11:25'),(75,0,'Sutejo','08782345645782','1983-01-01 17:00:00','tejo5@gmail.com','$2a$10$0YfmnGA9PoHzn08WCxsj.uJK67TReL2uHnHm.313ORLI75AhoGvJ.','Admin AO',1,'active','2020-09-02 05:04:35','2020-09-02 05:04:35'),(78,0,'Paulsen','08782345645782','1983-01-01 17:00:00','paulsenjs5@gmail.com','$2a$10$oV4zMFvtY4j8mGR0zGsf0O5whF3gWjWhV7nnodFzJaOTHqppDGSuC','Admin AO',1,'active','2020-09-02 05:08:54','2020-09-02 05:08:54'),(81,0,'Paulsen','08782345645782','1983-01-01 17:00:00','123@gmail.com','$2a$10$H8vn6r6vQU4.EulvGrTPVuY5qGxLJUKI/F8SnHRbtVPmTH4a9YIhy','AO/CMO/Sales Marketing',1,'active','2020-09-02 09:24:03','2020-09-02 09:24:03'),(83,0,'Paulsen','08782345645782','1983-01-01 17:00:00','124@gmail.com','$2a$10$GS9G8plwsH9x9DSJQm50wOrsBekjT1bbb/u.YYQ9aR1WtUXVKBnvq','AO/CMO/Sales Marketing',1,'active','2020-09-02 09:34:29','2020-09-02 09:34:29'),(84,0,'Paulsen','08782345645782','1983-01-01 17:00:00','125@gmail.com','$2a$10$xBxHW6mUIW154aX7gOb74eBG8iYxOrKK4rHUkMmTWF1/bsBYOwlXe','AO/CMO/Sales Marketing',1,'active','2020-09-02 09:41:55','2020-09-02 09:41:55'),(85,0,'Paulsen','08782345645782','1983-01-01 17:00:00','126@gmail.com','$2a$10$9aNSMg/yX55cXtruwkhwueviOq1bFgbNn4xhh7bqkIVul/wflm32i','AO/CMO/Sales Marketing',1,'active','2020-09-02 09:46:19','2020-09-02 09:46:19'),(86,0,'Paulsen','08782345645782','1983-01-01 17:00:00','127@gmail.com','$2a$10$9Aux7qYszhnRhI2/EeByB.LnKhoNgm6z.1XnAjAdhvM1z3JWd3jwa','AO/CMO/Sales Marketing',1,'active','2020-09-02 09:48:59','2020-09-02 09:48:59'),(87,10,'Sujarno','08782345645782','1983-01-01 17:00:00','128@gmail.com','$2a$10$E.3mpUjF38HRAaVggz4dTObUcxB1ZNj6HfXWtqsRv3lci9YKU1EUS','AO/CMO/Sales',1,'active','2020-09-02 09:51:14','2020-09-02 11:01:12'),(88,0,'Sumitro','08782345645782','1983-01-01 17:00:00','Mitro@gmail.com','$2a$10$E.3mpUjF38HRAaVggz4dTObUcxB1ZNj6HfXWtqsRv3lci9YKU1EUS','Admin',1,'active','2020-09-02 10:57:49','2020-09-02 10:57:49');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-04 17:59:38
